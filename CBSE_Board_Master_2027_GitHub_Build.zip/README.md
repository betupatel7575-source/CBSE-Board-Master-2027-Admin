# CBSE Board Master 2027 — Student Android App

Starter native Android app built with Kotlin + Jetpack Compose.

Current screens:
Home → Select Class → Subjects → Subject Menu → Practice Questions

Next integration:
1. Connect Firebase Authentication (optional).
2. Connect Firestore to the existing Admin Panel.
3. Load questions, chapters, sample papers and mock tests dynamically.
4. Add bookmarks, search, offline cache and notifications.
5. Prepare signed AAB for Google Play Store.

Important: do not upload Firebase private keys or service-account JSON to GitHub.


## Firebase setup
The supplied `app/google-services.json` is included for the registered package `com.cbseboardmaster.app`. Firebase SDK dependencies are enabled. Firestore/Auth usage still needs to be wired into the UI and Firebase Console rules/configuration.


## Phone-only build
This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
After the project is uploaded to a GitHub repository, open **Actions**, run **Build Android APK**, and download the generated APK from the workflow's **Artifacts** section.

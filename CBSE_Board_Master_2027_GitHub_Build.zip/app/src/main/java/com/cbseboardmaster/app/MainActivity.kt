package com.cbseboardmaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

data class Subject(val name: String, val emoji: String)
data class Question(val text: String, val answer: String, val year: String)

val class10 = listOf(
    Subject("English", "📘"), Subject("Hindi", "📕"), Subject("Mathematics", "📐"),
    Subject("Science", "🔬"), Subject("Social Science", "🌍"), Subject("Computer Applications", "💻")
)
val class12 = listOf(
    Subject("Biology", "🧬"), Subject("Physics", "⚡"), Subject("Chemistry", "🧪"),
    Subject("English Core", "📘"), Subject("Mathematics", "📐"), Subject("Accountancy", "💰"),
    Subject("Business Studies", "📊"), Subject("Economics", "📈"), Subject("History", "🏛️"),
    Subject("Political Science", "🏛️"), Subject("Geography", "🗺️"), Subject("Sociology", "👥")
)

@Composable
fun App() {
    var screen by remember { mutableStateOf("home") }
    var selectedClass by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf<Subject?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("CBSE Board Master 2027", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        if (screen != "home") TextButton(onClick = {
                            if (screen == "subjects") screen = "classes" else screen = "home"
                        }) { Text("←") }
                    }
                )
            }
        ) { pad ->
            when (screen) {
                "home" -> Home(pad) { screen = "classes" }
                "classes" -> Classes(pad) { selectedClass = it; screen = "subjects" }
                "subjects" -> Subjects(pad, selectedClass) {
                    selectedSubject = it; screen = "subjectMenu"
                }
                "subjectMenu" -> SubjectMenu(pad, selectedSubject!!) { screen = "questions" }
                "questions" -> Questions(pad, selectedSubject!!)
            }
        }
    }
}

@Composable
fun Home(pad: PaddingValues, onStart: () -> Unit) {
    Column(Modifier.padding(pad).padding(20.dp)) {
        Text("Prepare smarter for CBSE Board Exams", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("10-Year PYQs • Repeated Questions • Solutions • Mock Tests")
        Spacer(Modifier.height(24.dp))
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Start Preparation") }
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("What's inside?", fontWeight = FontWeight.Bold)
                Text("✓ Previous Year Questions")
                Text("✓ Chapter-wise practice")
                Text("✓ Answers & explanations")
                Text("✓ Mock tests")
            }
        }
    }
}

@Composable
fun Classes(pad: PaddingValues, onSelect: (String) -> Unit) {
    Column(Modifier.padding(pad).padding(20.dp)) {
        Text("Select Class", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onSelect("Class 10") }, Modifier.fillMaxWidth()) { Text("Class 10") }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { onSelect("Class 12") }, Modifier.fillMaxWidth()) { Text("Class 12") }
    }
}

@Composable
fun Subjects(pad: PaddingValues, cls: String, onSelect: (Subject) -> Unit) {
    val list = if (cls == "Class 10") class10 else class12
    LazyColumn(Modifier.padding(pad).padding(16.dp)) {
        item { Text("$cls Subjects", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)) }
        items(list) { s ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onSelect(s) }) {
                Row(Modifier.padding(18.dp)) { Text(s.emoji); Spacer(Modifier.width(12.dp)); Text(s.name) }
            }
        }
    }
}

@Composable
fun SubjectMenu(pad: PaddingValues, subject: Subject, onQuestions: () -> Unit) {
    Column(Modifier.padding(pad).padding(20.dp)) {
        Text("${subject.emoji} ${subject.name}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        listOf("10-Year Previous Year Questions", "Repeated / Important Questions", "Chapter-wise Questions", "Sample Papers", "Mock Tests").forEach {
            OutlinedButton(onClick = onQuestions, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(it) }
        }
    }
}

@Composable
fun Questions(pad: PaddingValues, subject: Subject) {
    val qs = listOf(
        Question("What is an important board-exam concept in ${subject.name}?", "Detailed answer and explanation will be added through the Admin Panel.", "2026"),
        Question("Practice question based on a repeated concept.", "Solution will be connected to Firebase.", "2025")
    )
    LazyColumn(Modifier.padding(pad).padding(16.dp)) {
        item { Text("${subject.name} — Practice Questions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)) }
        items(qs) { q ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("PYQ ${q.year}", style = MaterialTheme.typography.labelMedium)
                    Text(q.text, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Answer: ${q.answer}")
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
